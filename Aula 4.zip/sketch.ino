#include <Arduino.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

void TaskHigh(void *pv) 
{
  Serial.println("[HIGH] prio = 1 - running");
  while(1)
  {
    //Serial.println("[HIGH] prio = 1 - running");
    vTaskDelay(pdMS_TO_TICKS(1000));
  }
}

void TaskLow(void *pv) 
{
  while(1)
  {
    Serial.println("[LOW] prio = 1 - running");
    vTaskDelay(pdMS_TO_TICKS(1000));
  }
}

void setup() {
  Serial.begin(115200);

  xTaskCreate(TaskHigh, "High", 2048, nullptr, 2, nullptr);
  xTaskCreate(TaskLow, "Low", 2048, nullptr, 1, nullptr);
}

void loop() {

}
